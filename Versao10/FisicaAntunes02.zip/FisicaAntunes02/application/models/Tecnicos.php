<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Tecnicos extends CI_Model {
        function __construct() {
           parent::__construct();
          
        }

        public function listarTecnicos(){
            return $this->db->get('tecnicos')->result();
         }
        public function arquivosTecnico(){
            return $this->db->get('arquivosTecnico')->result();
         }
     public function vraw($idArquivo){
       $conteudo['arquivo'] = $this->db->get_where('arquivosTecnico',array('idArquivo='=>$idArquivo))->result();
       foreach($conteudo['arquivo'] as $arquivo){
           $idTecnico= $arquivo->idTecnico;
           $nomeArquivo = $arquivo->nomeArquivo;
       } 
       $this->db->where('nomeArquivo',$nomeArquivo);
      $this->db->where('idTecnico',$idTecnico);
        if($this->db->delete('arquivosTecnico')){
            $caminho_para_arquivo = './uploads/tecnicos/'.$idTecnico.'/'.$nomeArquivo;
            if(file_exists($caminho_para_arquivo)){
                if(unlink($caminho_para_arquivo)){
                   redirect('adm');
                }
            }      
        }else{
          echo 'deu ruim';
        } 
     }
   public function cadastrarTecnico($nomeTecnico){
         $dados = array(
     	    'nomeTecnico' => $nomeTecnico,
     	   );
         $this->db->insert('tecnicos',$dados);
      }
     
    public function verificaUpload($arquivoUpload,$idTecnico){
     $var=FALSE;
     $conteudo['arquivo'] = $this->db->get_where('arquivosTecnico',array('nomeArquivo='=>$arquivoUpload,'idTecnico='=>$idTecnico))->result();
       if($conteudo['arquivo'] != null){
           $var = TRUE;
       }  
        return $var;
     }

  public function obterIdArquivo($arquivoUpload,$idTecnico){
       $conteudo['arquivo'] = $this->db->get_where('arquivosTecnico',array('nomeArquivo='=>$arquivoUpload,'idTecnico='=>$idTecnico))->result();
       foreach($conteudo['arquivo'] as $arquivo){
           $idArquivo = $arquivo->idArquivo;
       }
        return $idArquivo;
    }

 public function renomear($id,$arqExc){
			$data = array(
        		'nomeArquivo' => $arqExc,
			);
        $this->db->where('idArquivo',$id);
        $this->db->update('arquivosTecnico',$data);
    }

   public function deletarRenomeado($idTecnico,$arqExc){
      $this->db->where('nomeArquivo',$arqExc);
        if($this->db->delete('arquivosTecnico')){
            $caminho_para_arquivo = './uploads/tecnicos/'.$idTecnico.'/'.$arqExc;
            if(file_exists($caminho_para_arquivo)){
                unlink($caminho_para_arquivo);           
            }      
        }else{
          echo 'deu ruim';
        } 
   }

public function nomeUpload($arquivoUpload,$idTecnico){
     	  $dados = array(
     	     'nomeArquivo' => $arquivoUpload,
           'idTecnico'=> $idTecnico
     	  );
           $this->db->insert('arquivosTecnico',$dados);
           
       }
      public function deletarArquivoTecnico($nomeArquivo,$idTecnico){
      $this->db->where('nomeArquivo',$nomeArquivo);
      $this->db->where('idTecnico',$idTecnico);
        if($this->db->delete('arquivosTecnico')){
            $caminho_para_arquivo = './uploads/tecnicos/'.$idTecnico.'/'.$nomeArquivo;
            if(file_exists($caminho_para_arquivo)){
                if(unlink($caminho_para_arquivo)){
                   redirect('adm');
                }
            }      
        }else{
          echo 'deu ruim';
        } 
   }

  public function arquivosPorTecnico($nomeTecnico){
        $conteudo['tecnico'] = $this->db->get_where('tecnicos', array('nomeTecnico=' => $nomeTecnico))->result();
          foreach($conteudo['tecnico'] as $tecnico){
            $idTecnico = $tecnico->idTecnico;
          }  
        
        return $this->db->get_where('arquivosTecnico', array('idTecnico=' => $idTecnico))->result();
        
     }
  
      public function obterIdTecnico($nomeTecnico){
        $conteudo['tecnico'] = $this->db->get_where('tecnicos', array('nomeTecnico=' => $nomeTecnico))->result();
          foreach($conteudo['tecnico'] as $tecnico){
            $idTecnico = $tecnico->idTecnico;
          }  
          return  $idTecnico;
      }
public function delTec($idTecnico){ 
      rmdir('../FisicaAntunes02/uploads/tecnicos/'.$idTecnico);
      $this->db->where('idTecnico',$idTecnico);
      $this->db->delete('tecnicos');
      redirect('adm');
      
    }
      public function deletarTecnico($idTecnico){
         $conteudo['arquivosExclusao'] = $this->db->get_where('arquivosTecnico', array('idTecnico=' => $idTecnico))->result();
           foreach($conteudo['arquivosExclusao'] as $arquivoExclusao){
             $this->db->where('idTecnico',$arquivoExclusao->idTecnico);
               if($this->db->delete('arquivosTecnico')){
                 $caminho_para_arquivo = './uploads/tecnicos/'.$idTecnico.'/'.$arquivoExclusao->nomeArquivo;
                   if(file_exists($caminho_para_arquivo)){
                      unlink($caminho_para_arquivo);
                   }      
               }
           }
         $conteudo['arquivosExclusao'] = $this->db->get_where('arquivosTecnico', array('idTecnico=' => $idTecnico))->result();
         if(!$conteudo['arquivosExclusao']){
            $this->delTec($idTecnico);
         }else{
           echo "Algo deu errado no processo";
         }
      }
    

      public function renomearTecnico($novoNome,$idTecnico){
        $data = array(
          'nomeTecnico' => $novoNome,
		  );
        $this->db->where('idTecnico',$idTecnico);
        $this->db->update('tecnicos',$data); 
        redirect('adm');
    }

}
