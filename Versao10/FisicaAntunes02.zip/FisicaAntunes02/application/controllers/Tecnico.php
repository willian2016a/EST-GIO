<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Tecnico extends CI_Controller {
    function __construct() {
        parent::__construct();
       /* $this->load->helper('file');
        $this->load->helper('download');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->library('upload');  
        $this->load->helper('string'); */    
    }
   public function vraw(){
    $this->load->model('Tecnicos','',TRUE);
    $idArquivo = $this->input->post('campo_idArquivo');
    $this->Tecnicos->vraw($idArquivo);
  }

  public function verificaTecnico(){
     $this->load->model('Tecnicos','',TRUE); 
     $arquivoOriginal = $_FILES['arquivo']['name']; 
     $idTecnico = $this->input->post('campo_idTecnico');  
     $verifica = $this->Tecnicos->verificaUpload($arquivoOriginal,$idTecnico); 
     if($verifica){
       $id = $this->Tecnicos->obterIdArquivo($arquivoOriginal,$idTecnico);
       $arqExc = 'arquivoqueseraexcluido';
       $velhoCaminho= '../FisicaAntunes02/uploads/tecnicos/'.$idTecnico.'/'.$arquivoOriginal;
       $novoCaminho= '../FisicaAntunes02/uploads/tecnicos/'.$idTecnico.'/'.$arqExc;
       rename($velhoCaminho,$novoCaminho);
       $this->Tecnicos->renomear($id,$arqExc);
       $this->Tecnicos->deletarRenomeado($idTecnico,$arqExc);
       $this->salvar($arquivoOriginal,$idTecnico);
      }else{
         $this->salvar($arquivoOriginal,$idTecnico); 
     }
     
  }

	public function salvar($arquivo,$idTecnico){    
            $this->load->model('Tecnicos','',TRUE); 
    			$configuracao = array(
    		    'upload_path'   => './uploads/',
    		    'allowed_types' => 'jpg|png|gif|pdf|zip|rar|doc|xls|mp3',
    		    'max_size'      => '0',
             'remove_spaces' => 'TRUE',
    	      );     
            $path = './uploads/tecnicos/'.$idTecnico.'/';
            $configuracao['upload_path'] = $path;
    	 $this->upload->initialize($configuracao);
    	 if($this->upload->do_upload('arquivo')){
         $procura = '..';
         $substituto = '__';
         $arquivo = str_replace($procura,$substituto,$arquivo);
          $this->Tecnicos->nomeUpload($arquivo,$idTecnico);
           echo 'Arquivo salvo com sucesso';
        	  redirect('adm');
     	 }else{
       	  echo $this->upload->display_errors();
       	 }  
   }


   public function renomearTecnico(){
       $this->load->model('Tecnicos','',TRUE);  
       $novoNome = $this->input->post('novoNome');
       $idTecnico = $this->input->post('campo_idTecnico');
       $this->Tecnicos->renomearTecnico($novoNome,$idTecnico); 
       
   }


   public function download(){
     $nomeArquivo = $this->input->post('campo_nomeArquivo');
     $idTecnico = $this->input->post('campo_idTecnico');
     $arquivoPath = './uploads/tecnicos/'.$idTecnico.'/'.$nomeArquivo;
    // forçamos o download no browser 
     // passando como parâmetro o path original do arquivo
     force_download($arquivoPath,null);    
   }


   public function deletarTecnico(){
     $this->load->model('Tecnicos','',TRUE); 
     $idTecnico = $this->input->post('campo_idTecnico');
     $this->Tecnicos->deletarTecnico($idTecnico);
     
   }


  public function deletarArquivoTecnico(){
    $this->load->model('Tecnicos','',TRUE);
    $nomeArquivo = $this->input->post('campo_nomeArquivo');
    $idTecnico = $this->input->post('campo_idTecnico');
    $this->Tecnicos->deletarArquivoTecnico($nomeArquivo,$idTecnico); 
  
  }

  


  public function cadastroTecnico(){
    $this->load->model('Tecnicos','',TRUE);
    $nome = $this->input->post('nomeTecnico');
    $nomeTecnico = $nome;
    $this->Tecnicos->cadastrarTecnico($nomeTecnico);
    $idTecnico = $this->Tecnicos->obterIdTecnico($nomeTecnico);
    mkdir('../FisicaAntunes02/uploads/tecnicos/'.$idTecnico, 0777);
    redirect('adm');
  }


  public function tecnico($nomeTecnico){
     $nomeTecnico = urldecode($nomeTecnico);
     $this->load->model('Tecnicos','',TRUE); 
     $this->load->model('Disciplinas','',TRUE); 
     $conteudo['arquivosTecnico'] = $this->Tecnicos->arquivosPorTecnico($nomeTecnico);
     $conteudo['tecnicos'] = $this->Tecnicos->listarTecnicos();
     $conteudo['disciplinas'] = $this->Disciplinas->listarDisciplinas();
     $conteudo['logo'] = mb_substr($nomeTecnico,0,3);
     $conteudo['logo'] = strtolower($conteudo['logo']);
 
	 if ($conteudo['logo'] == "lab"){
         $conteudo['logo'] = "laboratorio";
      } else {
         $conteudo['logo'] = "fisica";
      }
    
     $this->load->view('tecnicoGenerico',$conteudo);	
   }




}
