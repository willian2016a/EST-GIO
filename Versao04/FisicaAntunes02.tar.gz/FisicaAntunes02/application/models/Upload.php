<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Upload extends CI_Model{
        function __construct(){
           parent::__construct();
        }
 
     public function nomeUpload($arquivoUpload){
     	  $dados = array(
     	     'nome' => $arquivoUpload
     	  );
          $var = FALSE;
          $arquivos = $this->db->get('arquivos')->result();
          foreach($arquivos as $arq){
             if($arq->nome == $arquivoUpload){
                $var = TRUE;
             }
          
          }

          if(!$var){
     	    $this->db->insert('arquivos',$dados);
            redirect('home/graduacao');
          }else{
            redirect('home/teste');
          }
     }

     public function consultarNomes(){
        return $this->db->get('arquivos')->result();
     }
     

 


     public function deletar($nomeArquivo){
       
        $this->db->where('nome',$nomeArquivo);
        if($this->db->delete('arquivos')){
            $caminho_para_arquivo = './uploads'."/".$nomeArquivo;
            if(file_exists($caminho_para_arquivo)){
                if(unlink($caminho_para_arquivo)){
                   redirect('home/graduacao');
                }
            }
            
        }else{
          echo 'deu ruim';
        }
     }



     public function deletarComp($idComp){
        $this->db->where('id',$idComp);
        if($this->db->delete('compromissos')){
          redirect('home/graduacao');
        }
     }
    
}
