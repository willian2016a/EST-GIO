<div id="horarios">
   <?php 
               foreach($resultado as $re){
            		echo $re->conteudo .br();
           		    echo $re->dataCadastro .br();
                    echo $re->dataMarcada;
               }
                   
              
    ?>
</div>





   
</body>
</html>
