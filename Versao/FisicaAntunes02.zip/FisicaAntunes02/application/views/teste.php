<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>Física Antunes</title>
    <link href="http://localhost/FisicaAntunes02/assets/css/estilos.css" rel="stylesheet">
    <link href="http://localhost/FisicaAntunes02/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="http://localhost/FisicaAntunes02/assets/jquery-3.2.0.min.js"  type="text/javascript"></script>
    <script src="http://localhost/FisicaAntunes02/assets/bootstrap/js/bootstrap.min.js"  type="text/javascript"></script>
   
    
</head>
<body>    
  <?php
    $addUpload = array('name' => 'arquivo','value' => 'Arquibao','type'=>'file');
    $addSubmit = array('name' => 'submit','value' => 'Enviar');
    $add = array('name'=>'userfile');
    echo form_open_multipart("home/salvar").
         form_input($addUpload). br().
         form_input($add). br().
         form_submit($addSubmit).br().
         form_close();

 ?>   
   
</body>
</html>
