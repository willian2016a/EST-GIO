<!DOCTYPE html>
<html lang="pt-br">
    <head>
	   <meta charset="UTF-8">
	   <title>Física Antunes</title>
        <link href="http://localhost/FisicaAntunes02/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <script src="http://localhost/FisicaAntunes02/assets/jquery-3.2.0.min.js"  type="text/javascript"></script>
        <script src="http://localhost/FisicaAntunes02/assets/bootstrap/js/bootstrap.min.js"  type="text/javascript"></script>
		<link href="http://localhost/FisicaAntunes02/assets/css/estilosADM.css" rel="stylesheet">
		<script>

			$(document).ready(function(){
				$('.caixaEvento').hide();
			});
			var cont3=1;
			function MostrarEvento(){
				var aux = document.querySelector('#EventoId').name;
				$(aux).show();	
				cont3 =0;
			}
			function EsconderEvento(){
				var aux = document.querySelector('#EventoEsconder').name;
				$(aux).hide();	
				cont3 =1;
			}
		
		</script>
    </head>
    <body>
	<div id="content">
    	<div id="eletronfoto">
			<div id="logo">
				<img id="logoCefet" src="http://localhost/FisicaAntunes02/assets/images/logoCefet.jpg"></img> 
			</div>
			<div id="titulo">
				<p id="titulo1">Pedro Antunes Duarte, MSc</p>
				<p id="titulo2">MESTRE EM CIÊNCIAS - MATERIAIS PARA ENGENHARIA</p>
			</div>
		</div> 
    	<div id="Meenu">
        	<nav id="menunav">
        	    <ul id="menu" class="nav nav-tabs">
        	        <li>
        	            <form action="http://localhost/FisicaAntunes02/home"><button id="menuu" type="submit" class="btn btn-default navbar-btn"><b>Home</b></button></form>
        	         </li>                        
                    	<li>
                     		<a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" id="menuu">Graduação<span class="caret"></span></a>
                    		<ul id="menuuu" class="dropdown-menu">
                          		<?php 
									foreach($disciplinas as $disciplina){
                        				?>
                        				<li>
                          	 				<?php 
												echo anchor(base_url("disciplina/disciplina/".$disciplina->nome),'<span id="drop">' . $disciplina->nome . '</span>');
                          	 				?>
                        				</li>
                          				<?php
                          					}
                        				?>
                     		</ul> 
                    	</li>
                    	<li>
                     		<a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" id="menuu">Técnicos<span class="caret"></span></a>
                     		<ul id="menuuu" class="dropdown-menu">
                          		<?php 
									foreach($tecnicos as $tecnico){
                        	  ?>
                  			   <li>
                           	 <?php echo anchor(base_url("tecnico/tecnico/".$tecnico->nomeTecnico),'<span id="drop">' . $tecnico->nomeTecnico. '</span>');
                           	 ?> 
                          		</li>
                       
                         				<?php
                          					}
                        				?>
                     		</ul> 
                    	</li>
                     <li>
                        <form action="http://localhost/FisicaAntunes02/home"><button id="menuu" type="submit" class="btn btn-default navbar-btn"><b>Eventos</b></button></form>
                     </li>
                    	<li>
                       <?php if($this->session->userdata('logado') == 'TRUE'){
           $subADM = array('class' => 'btn btn-default dropdown-toggle','id' => 'menuu');
           echo form_open(base_url("adm")) .
                form_submit('nomequalquer','Administração',$subADM).
                form_close();
         }else{
          ?>
<button type="button" class="btn btn-default navbar-btn" id="menuu" data-toggle="modal" data-target="#loginADM">ADM</button>
           	<div class="modal fade" id="loginADM" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            	<div class="modal-dialog" role="document">
            	    <div class="modal-content">
            	        <div class="modal-header">
            	            <h4 class="modal-title" id="exampleModalLabel02">Para permissões administrativas, insira sua senha:</h4>
            	        </div>
            	        <div class="modal-body">
           		            <div class="form-group">
           		                <?php
                                $infoss = array('class' => 'form-label');
          		                $info = array('class' => 'form-control');
          		                $infos = array('class' => 'btn btn-default dropdown-toggle','id' => 'botao');
	      		                   echo form_open(base_url("adm/login")) .
          		                    form_label("Senha: " ,"txt_senha",$infoss).br() .
                                       form_input("txt_camposenha",'',$info) . br().
                                       form_submit('nomequalquer','Enviar Mensagem',$infos).
                                       form_close();
            	                ?>
            	            </div>
            	        </div>  
            	    </div>
            	</div>
        	</div>
     <?php
         }
     ?>




                    	<li>   
                        	<button type="button" class="btn btn-default navbar-btn" id="menuu" data-toggle="modal" data-target="#exampleModal"><b>Contato</b></button> 
                    	</li>   
            	</ul>  
        	</nav>
			<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
	            <div class="modal-dialog" role="document">
	                <div class="modal-content">
	                    <div class="modal-body">
          
             Telefones (CEFET - Formação Geral): (35) 3690-4216  <br>
                                                (35) 3690-4214  <br>
                                                (35) 3690-4234  <br>
             Email: pedroantunes.pd@gmail.com <br>
                    antunes.pd@gmail.com
        
	                    </div>
	                </div>
	            </div>
	        </div>
        	<div class="modal fade" id="exampleModal02" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            	<div class="modal-dialog" role="document">
            	    <div class="modal-content">
            	        <div class="modal-header">
            	            <h4 class="modal-title" id="exampleModalLabel02">Para permissões administrativas, insira sua senha:</h4>
            	        </div>
            	        <div class="modal-body">
           		            <div class="form-group">
           		                <?php
                                $infoss = array('class' => 'form-label');
          		                $info = array('class' => 'form-control');
          		                $infos = array('class' => 'btn btn-default dropdown-toggle','id' => 'botao');
	      		                   echo form_open(base_url("home/login")) .
          		                    form_label("Senha: " ,"txt_senha",$infoss).br().
                                       form_input("txt_camposenha",'',$info) . br().
                                       form_submit('nomequalquer','Enviar Mensagem',$infos).
                                       form_close();
            	                ?>
            	            </div>
            	        </div>  
            	    </div>
            	</div>
        	</div>





<div id="tudo">
 <?php 
                 foreach($eventos as $evento){
             ?>  

        <div class="caixaEvento"  id="<?php echo $evento->idEvento;?>">
              <?php
                  echo nl2br($evento->conteudoEvento);
    				?>
					<input id="EventoEsconder" name="#" value="Esconder" type="submit" onClick="EsconderEvento()"></input>
				
        </div>
 </div> 


           <?php 
                 }
            ?> 

<!--
	 <a id="descricaoEvento" href="#">
		<img id="mae" border="0" alt="imagemEvento" src="http://localhost/FisicaAntunes02/uploads/eventos/11" width="100" height="100">
	 </a>
	

-->



 <div class="eventosE">
		<img id="EventoId" href="#" border="3px" name="#" alt="imagemEvento" onClick="MostrarEvento()" src="http://localhost/FisicaAntunes02/uploads/eventos/11" width="200" height="200">
		
	 	
 </div>














<!--
   <input  id="eventoButton" type="image" src="http://localhost/FisicaAntunes02/uploads/eventos/11" 
	href="http://localhost/FisicaAntunes02/application/controllers/evento">
	
	

		<?php
           	
           	$info = array('id' => 'eventoButton','type'=>'image','scr'=>"http://localhost/FisicaAntunes02/uploads/eventos/10" );
				$oculto = array('name'=>'campo_oculo','value'=>'FisicaAntunes');
	      		 echo form_open(base_url("evento/descricao")) .
							form_hidden($oculto).br().
                     form_input($info) . br().
                     form_close();
        ?>





<div class = "Topo">
	<img src="http://localhost/FisicaAntunes02/uploads/eventos/image1.png">
</div>
-->


<script>
 var cont=0;
 var banners = [];
 var idBanners = [];
</script>
<?php  
  foreach($eventos as $evento){
?>
<script>
	banners[cont] = "<?php echo 'http://localhost/FisicaAntunes02/uploads/eventos/'.$evento->idEvento;?>";
	idBanners[cont] = "<?php echo '#'.$evento->idEvento;?>";
	cont++;
</script>
<?php
 }
?>

<script>
var bannerAtual = -1;
function trocaBanner() {
	bannerAtual++;
	if(cont3 == 1){
		if(bannerAtual<cont){  	
			document.querySelector('#EventoId').name = idBanners[bannerAtual];
			document.querySelector('#EventoEsconder').name = idBanners[bannerAtual];
			document.querySelector('#EventoId').src = banners[bannerAtual];
		}else{
			bannerAtual = 0;  	
			document.querySelector('#EventoId').name = idBanners[bannerAtual];
			document.querySelector('#EventoEsconder').name = idBanners[bannerAtual];
			document.querySelector('#EventoId').src = banners[bannerAtual];
		}
	}
}

setInterval(trocaBanner,3000) ;
</script>

</div>


			<footer>
				<div id="rodape">
				</div>
			</footer>
		</div>
    </body>
</html>
