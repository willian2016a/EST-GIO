<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>Física Antunes</title>
    <link href="http://localhost/FisicaAntunes02/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="http://localhost/FisicaAntunes02/assets/jquery-3.2.0.min.js"  type="text/javascript"></script>
    <script src="http://localhost/FisicaAntunes02/assets/bootstrap/js/bootstrap.min.js"  type="text/javascript"></script>
	 <link href="http://localhost/FisicaAntunes02/assets/css/estilosADM.css" rel="stylesheet">
    
    <?php
  /*$var = "1";
  if($var == "1"){
echo '<script> $(document).ready(function(){
            $("#cadastrarTecnico").modal();
        });
    </script>';
  }*/
?>
</head>
<body>  

    	<div id="eletronfoto">
			<div id="logo">
				<img id="logoCefet" src="http://localhost/FisicaAntunes02/assets/images/logoCefet.jpg"></img> 
			</div>
			<div id="titulo">
				<p id="titulo1">Pedro Antunes Duarte, MSc</p>
			</div>
		</div>
	
        	<nav id="menunav">
        	    <ul id="menu" class="nav nav-tabs">
        	        <li>
        	            <form action="http://localhost/FisicaAntunes02/home"><button id="menuu" type="submit" class="btn btn-default navbar-btn"><b>Home</b></button></form>
        	         </li>                        
                    	<li>
                     		<a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" id="menuu">Graduação<span class="caret"></span></a>
                    		<ul id="menuuu" class="dropdown-menu">
                          		<?php 
									foreach($disciplinas as $disciplina){
                        				?>
                        				<li>
                          	 				<?php 
												echo anchor(base_url("disciplina/disciplina/".$disciplina->nome),'<span id="drop">' . $disciplina->nome . '</span>');
                          	 				?>
                        				</li>
                          				<?php
                          					}
                        				?>
                     		</ul> 
                    	</li>
                    	<li>
                     		<a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" id="menuu">Técnicos<span class="caret"></span></a>
                     		<ul id="menuuu" class="dropdown-menu">
                          		<?php 
									foreach($tecnicos as $tecnico){
                        	  ?>
                  			   <li>
                           	 <?php echo anchor(base_url("tecnico/tecnico/".$tecnico->nomeTecnico),'<span id="drop">' . $tecnico->nomeTecnico. '</span>');
                           	 ?> 
                          		</li>
                       
                         				<?php
                          					}
                        				?>
                     		</ul> 
                    	</li>
                     <li>
                        <form action="http://localhost/FisicaAntunes02/home"><button id="menuu" type="submit" class="btn btn-default navbar-btn"><b>Eventos</b></button></form>
                     </li>
                    	<li>
                       <?php if($this->session->userdata('logado') == 'TRUE'){
           $subADM = array('class' => 'btn btn-default dropdown-toggle','id' => 'menuu');
           echo form_open(base_url("adm")) .
                form_submit('nomequalquer','ADM',$subADM).
                form_close();
         }else{
          ?>
<button type="button" class="btn btn-default navbar-btn" id="menuu" data-toggle="modal" data-target="#loginADM">ADM</button>
           	<div class="modal fade" id="loginADM" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            	<div class="modal-dialog" role="document">
            	    <div class="modal-content">
            	        <div class="modal-header">
            	            <h4 class="modal-title" id="exampleModalLabel02">Para permissões administrativas, insira sua senha:</h4>
            	        </div>
            	        <div class="modal-body">
           		            <div class="form-group">
           		                <?php
                                $infoss = array('class' => 'form-label');
          		                $info = array('class' => 'form-control');
          		                $infos = array('class' => 'btn btn-default dropdown-toggle','id' => 'botao');
	      		                   echo form_open(base_url("adm/login")) .
          		                    form_label("Senha: " ,"txt_senha",$infoss).br() .
                                       form_input("txt_camposenha",'',$info) . br().
                                       form_submit('nomequalquer','Enviar Mensagem',$infos).
                                       form_close();
            	                ?>
            	            </div>
            	        </div>  
            	    </div>
            	</div>
        	</div>
     <?php
         }
     ?>
                 </li>
                    	<li>   
                        	<button type="button" class="btn btn-default navbar-btn" id="menuu" data-toggle="modal" data-target="#exampleModal"><b>Contato</b></button> 
                            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
	                    <div class="modal-dialog" role="document">
	                        <div class="modal-content">
	                           <div class="modal-body">
          
                              Telefones(CEFET - Formação Geral): (35) 3690-4216  <br>
                                                (35) 3690-4214  <br>
                                                (35) 3690-4234  <br>
                               Email: pedroantunes.pd@gmail.com <br>
                               antunes.pd@gmail.com
        
	                    </div>
	                </div>
	            </div>
	        </div>
                    	</li> 
							<li>
<button type="button" class="btn btn-default navbar-btn" id="menuu" data-toggle="modal" data-target="#logoutADM">LogOut</button>
           	<div class="modal fade bd-example-modal-sm" id="logoutADM" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            	<div id="logoutD" class="modal-dialog modal-sm" role="document">
            	    <div class="modal-content">
            	        <div class="modal-header">
            	            <h4 class="modal-title" id="exampleModalLabel02">Deseja fazer o Logout?</h4>
            	        </div>
            	        <div class="modal-body">
           		            <div class="form-group">
           		                <?php
          		                $infos = array('class' => 'btn btn-default dropdown-toggle','id' => 'botao');
	      		                   echo form_open(base_url("adm/logout")) .
                                       form_submit('nomequalquer','OK',$infos).
                                       form_close();
            	                ?>
            	            </div>
            	        </div>  
            	    </div>
            	</div>
        	</div>
                 </li>  
            	</ul>  
        	</nav>
			
        	<div class="modal fade" id="exampleModal02" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            	<div class="modal-dialog" role="document">
            	    <div class="modal-content">
            	        <div class="modal-header">
            	            <h4 class="modal-title" id="exampleModalLabel02">Para permissões administrativas, insira sua senha:</h4>
            	        </div>
            	        <div class="modal-body">
           		            <div class="form-group">
           		                <?php
                                $infoss = array('class' => 'form-label');
          		                $info = array('class' => 'form-control');
          		                $infos = array('class' => 'btn btn-default dropdown-toggle','id' => 'botao');
	      		                   echo form_open(base_url("home/login")) .
          		                    form_label("Senha: " ,"txt_senha",$infoss).br() .
                                       form_input("txt_camposenha",'',$info) . br().
                                       form_submit('nomequalquer','Enviar Mensagem',$infos).
                                       form_close();
            	                ?>
            	            </div>
            	        </div>  
            	    </div>
            	</div>
        	</div>


















<div id="info">
	

<div id="tabela1">
		<h2>Arquivos das Disciplinas</h2> 
 			<table border="1" id="tabel"> 
  			<?php    
    			foreach($arquivosDisciplina as $arquivoDisciplina){
    		?>
     		<tr>

      		<td>
  					<?php  
          			$submitDownload = array('name'=>'nomeArquivo','value'=>$arquivoDisciplina->nomeArquivo,'class'=>'btn btn-default navbar-btn');
                  
     					echo form_open_multipart("disciplina/download").
          form_submit($submitDownload). 
          form_hidden('campo_nomeArquivo',$arquivoDisciplina->nomeArquivo).
          form_hidden('campo_idDisciplina',$arquivoDisciplina->idDisciplina).
          form_close();
    
     				?>
      		</td>

      		<td>
           <button type="button" id="a"  data-toggle="modal" 
        data-target="#<?php echo sha1(md5($arquivoDisciplina->idArquivo));?>"><b>Excluir</b></button>
  <div class="modal fade" id="<?php echo sha1(md5($arquivoDisciplina->idArquivo)) ;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                     
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                               echo "Deseja realmente excluir esse arquivo de Disciplina?".$arquivoDisciplina->idArquivo;
          		               $submitExcluir = array('name'=>'oculto','id'=>'Excl','value'=>'Excluir','class'=>'btn btn-default navbar-btn');
      				           echo form_open_multipart('disciplina/vraw').
                             form_submit($submitExcluir).
                             form_hidden('campo_idArquivo',$arquivoDisciplina->idArquivo).
                             form_close();
                            ?>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
     			</td>

     		</tr>
   		<?php 
    			}
   		?> 
		</table>
	</div>

	<div id="tabela2">
			<table border="1" id="tabel"> 
  				<h2>Arquivos dos Técnicos</h2> 
  				<?php    
    				foreach($arquivosTecnico as $arquivoTecnico){
    			?>
     			<tr>
      			<td>
   					<?php  
          				$submitDownload = array('name'=>'nomeArquivo','value'=>$arquivoTecnico->nomeArquivo.$arquivoTecnico->idTecnico,'class'=>'btn btn-default navbar-btn');

     						echo form_open_multipart("tecnico/download").
          form_submit($submitDownload).
          
          form_hidden('campo_nomeArquivo',$arquivoTecnico->nomeArquivo).
          form_hidden('campo_idTecnico',$arquivoTecnico->idTecnico).
          form_close();
       ?>		
      	</td>


      	<td>
<button type="button" id="cadastrar" data-toggle="modal" 
        data-target="#<?php echo sha1(md5($arquivoTecnico->idArquivo));?>"><b>Excluir</b></button>
  <div class="modal fade" id="<?php echo sha1(md5($arquivoTecnico->idArquivo)) ;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Excluir Arq:</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                               echo "Deseja realmente excluir esse arquivo do Tecnico ?".$arquivoTecnico->nomeArquivo;
          		               $submitExcluir = array('name'=>'oculto','value'=>'Excluir','class'=>'btn btn-default navbar-btn');
      				           echo form_open_multipart('tecnico/deletarArquivoTecnico').
                             form_submit($submitExcluir).
                             form_hidden('campo_nomeArquivo',$arquivoTecnico->nomeArquivo).    
                             form_hidden('campo_idTecnico',$arquivoTecnico->idTecnico).
                             form_close();
                            ?>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
     				</td>


     			</tr>
   			<?php 
    				}
    			?> 
			</table>
</div>




<div id="ragnarok">
				<div id="tabela1">
                <table border="1" id="tabel">
                        <?php
                          foreach($disciplinas as $disciplina){
                        ?>
                        <tr>
                         <td>
                           <?php
                           
                              $submitRenomear = array('name'=>$disciplina->idDisciplina,'value'=>'Renomear','class'=>'btn btn-default navbar-btn');
                               $info = array('class' => 'form-control');
	      		                   echo form_open('disciplina/renomearDisciplina').
                                       form_input("novoNome",$disciplina->nome,$info).
                                       form_hidden('campo_idDisciplina',$disciplina->idDisciplina).
                                       form_submit($submitRenomear).
                                       form_close();
                            ?>
<button type="button" id="cadastrar" data-toggle="modal" 
        data-target="#<?php echo sha1(md5($disciplina->idDisciplina));?>"><b>Excluir</b></button>
  <div class="modal fade" id="<?php echo sha1(md5($disciplina->idDisciplina));?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Excluir Disciplina:</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                               echo "Deseja realmente excluir essa disciplina ?";
          		               $submitExcluir = array('name'=>'oculto','value'=>'Excluir','class'=>'btn btn-default navbar-btn');
      				           echo form_open_multipart('disciplina/deletarDisciplina').
                             form_submit($submitExcluir).
                             form_hidden('campo_idDisciplina',$disciplina->idDisciplina).
                             form_close();
                            ?>
                        </div>
                    </div>  
                </div>
            </div>
        </div> 
 
                         </td>
                          <td>
                            <?php
                              $addUpload = array('name' => 'arquivo','value' => 'Arquibao',
                                         'type'=>'file','class'=>'btn btn-default navbar-btn');     
    									$addSubmit = array('name' => 'dcsd','type'=>'submit', 'value'=> 'true', 'content'=> 'Teste');    
    									echo form_open_multipart("disciplina/verificaDisciplina").
         							form_upload($addUpload).
                              form_hidden('campo_idDisciplina',$disciplina->idDisciplina).
                              form_button($addSubmit). 
         							form_close();
    								 ?>
                         </td>
                         </tr>
                          <?php
                          }
                        ?>
                   
              
<button type="button" class="btn btn-default navbar-btn" id="cadastrar" data-toggle="modal" data-target="#cadastrarDisciplina"><b>CADASTRAR DISCIPLINA</b></button>
  <div class="modal fade" id="cadastrarDisciplina" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Nova disciplina:</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                                
          		                $info = array('class' => 'form-control');
          		                $infos = array('class' => 'btn btn-default dropdown-toggle','id' => 'botao');
	      		                   echo form_open(base_url("disciplina/cadastroDisciplina")) .
                                       form_input("nomeDisciplina",'',$info) . br().
                                       form_submit('nomequalquer','Cadastrar',$infos).
                                       form_close();
                            ?>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
                </table>  
</div>
      









   <div id="tabela2">
   <table border="1" id="tabel">
                        <?php
                          foreach($tecnicos as $tecnico){
                        ?>
                        <tr>
                         <td>
                           <?php
                              
                              $submitRenomear = array('name'=>$tecnico->idTecnico,'value'=>'Renomear','class'=>'btn btn-default navbar-btn');
                               $info = array('class' => 'form-control');
	      		                   echo form_open('tecnico/renomearTecnico').
                                       form_input("novoNome",$tecnico->nomeTecnico.$tecnico->idTecnico,$info).
                                       form_hidden('campo_idTecnico',$tecnico->idTecnico).
                                       form_submit($submitRenomear).
                                       form_close();
                           ?> 

<button type="button" class="btn btn-default navbar-btn" id="cadastrar" data-toggle="modal" 
    data-target="#<?php echo md5($tecnico->idTecnico);?>"><b>Excluir</b></button>
  <div class="modal fade" id="<?php echo md5($tecnico->idTecnico);?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Noscsdcascasdcas</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                               echo "Deseja realmente excluir esse técnico ?";
          		               $submitExcluir = array('name'=>'oculto','value'=>'Excluir','class'=>'btn btn-default navbar-btn');
      				           echo form_open_multipart('tecnico/deletarTecnico').
                             form_submit($submitExcluir).
                             form_hidden('campo_idTecnico',$tecnico->idTecnico).
                             form_close();
                            ?>
                        </div>
                    </div>  
                </div>
            </div>
        </div>


 
                         </td>


                          <td>
                            <?php
                              $addUpload = array('name' => 'arquivo','value' => 'Arquibao',
                                         'type'=>'file','class'=>'btn btn-default navbar-btn');     
    									$addSubmit = array('name' => 'submit','value' => 'Enviar','class'=>'btn btn-default navbar-btn');    
    									echo form_open_multipart("tecnico/verificaTecnico").
         							form_upload($addUpload).
                              form_hidden('campo_idTecnico',$tecnico->idTecnico).
                              form_submit($addSubmit). 
         							form_close();
    								 ?>
                         </td>


                         </tr>
                          <?php
                          }
                        ?>
                
              
<button type="button" class="btn btn-default navbar-btn" id="cadastrar" data-toggle="modal" data-target="#cadastrarTecnico"><b>CADASTRAR TÉCNICO</b></button>
  <div class="modal fade" id="cadastrarTecnico" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Novo Técnico:</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                                
          		                $info = array('class' => 'form-control');
          		                $infos = array('class' => 'btn btn-default dropdown-toggle','id' => 'botao');
	      		                   echo form_open(base_url("tecnico/cadastroTecnico")) .
                                       form_input("nomeTecnico",'',$info) . br().
                                       form_submit('nomequalquer','Cadastrar',$infos).
                                       form_close();
                            ?>
                        </div>
                    </div>  
                </div>
            </div>
        </div>

      </table> 



      </div>
	</div>
	 
</div>
  



<div id="tudo">
 <?php 
                 foreach($eventos as $evento){
             ?>  

      <div class="evento">
                   <input  id="eventoButton" type="image" src="http://localhost/FisicaAntunes02/uploads/eventos/<?php echo $evento->idEvento;?>"  class="btn btn-default navbar-btn" id="eventoButton" 
                  data-toggle="modal" data-target="#<?php echo sha1($evento->idEvento);?>" >


        <div class="modal fade" id="<?php echo sha1($evento->idEvento);?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Evento:</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                             $alterar = array('value'=>'Salvar Alterações');
                             $c = array('name'=>'conteudoEvento','value'=>$evento->conteudoEvento,'id'=>'conteudoEvento');
                         echo form_open_multipart("evento/alterarEvento").
                              form_textarea($c). 
                              form_hidden('campo_idEvento',$evento->idEvento).
                              form_submit($alterar). 
         							form_close()      
    								 ?>
                           <?php
                             $excluir = array('value'=>'Excluir');
                         echo form_open_multipart("evento/excluirEvento").
                              form_hidden('campo_idEvento',$evento->idEvento).
                              form_submit($excluir). 
         							form_close()      
    								 ?>
                        </div>
                    </div>  
                </div>
            </div>
        </div> 

</div>
           <?php 
                 }
            ?> 
 <div id="x">
 <?php 
    $dados = array('class'=>'btn btn-default navbar-btn1','data-toggle'=>'modal', 
            'data-target'=>'#cadastrarevento','content'=>'Evento','id'=>'cadastrar');
    echo form_button($dados);
 ?>
</div>
<div class="modal fade" id="cadastrarevento" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Evento:</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                              $addUpload = array('name' => 'arquivo','value' => 'Arquibao',
                                         'type'=>'file','class'=>'btn btn-default navbar-btn');     
    									$addSubmit = array('name' => 'dcsd', 'value'=> 'Cadastrar', 'content'=> 'Teste');
                              $addTextArea = array('name'=>'conteudoEvento');    
    									echo form_open_multipart("evento/cadastrarEvento").
         							form_upload($addUpload).
                              form_textarea($addTextArea).
                              form_submit($addSubmit). 
         							form_close();
    								 ?>
                         
                        </div>
                    </div>  
                </div>
            </div>
        </div>  

</div>






</body>
</html>
