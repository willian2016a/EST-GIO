<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Disciplinas extends CI_Model {
        function __construct() {
           parent::__construct();
          
        }

        public function listarDisciplinas(){
            return $this->db->get('disciplinas')->result();
           
         }
        public function conteudoDisciplina($conteudo){
           return $this->db->get_where('mytable', array('id' => $id), $limit, $offset);
        }
}
