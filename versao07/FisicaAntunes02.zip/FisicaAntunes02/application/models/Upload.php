<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Upload extends CI_Model{
        function __construct(){
           parent::__construct();
        }
 
     public function nomeUpload($arquivoUpload){
     	  $dados = array(
     	     'nomeArq' => $arquivoUpload
     	  );
          $var = FALSE;
          $arquivos = $this->db->get('arquivo')->result();
          foreach($arquivos as $arq){
             if($arq->nomeArq == $arquivoUpload){
                $var = TRUE;
             }
          
          }

          if(!$var){
     	    $this->db->insert('arquivo',$dados);
            redirect('home/teste');
          }else{
            redirect('home/teste');
          }
     }

     public function consultarNomes(){
        return $this->db->get('arquivo')->result();
     }
     

 


     public function deletar($nomeArquivo){
       
        $this->db->where('nomeArq',$nomeArquivo);
        if($this->db->delete('arquivo')){
            $caminho_para_arquivo = './uploads'."/".$nomeArquivo;
            if(file_exists($caminho_para_arquivo)){
                if(unlink($caminho_para_arquivo)){
                   redirect('home/teste');
                }
            }
            
        }else{
          echo 'deu ruim';
        }
     }



     public function deletarComp($idComp){
        $this->db->where('id',$idComp);
        if($this->db->delete('compromissos')){
          redirect('home/graduacao');
        }
     }
    
}
