<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Graduacao extends CI_Model {
        function __construct() {
           parent::__construct();
          
        }

        public function consultarHorarios(){
           //obter os dados que vêm do banco na tabela horarios
            return $this->db->get('horarios')->result();
           
         }

}
