<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Upload extends CI_Model{
        function __construct(){
           parent::__construct();
        }
 
     public function nomeUpload($arquivoUpload){
     	  $dados = array(
     	     'nome' => $arquivoUpload
     	  );
          $var = FALSE;
          $arquivos = $this->db->get('arquivos')->result();
          foreach($arquivos as $arq){
             if($arq->nome == $arquivoUpload){
                $var = TRUE;
             }
          
          }

          if(!$var){
     	    $this->db->insert('arquivos',$dados);
            redirect('home/teste');
          }else{
            redirect('home/teste');
          }
     }

     public function consultarNomes(){
        return $this->db->get('arquivos')->result();
     }

     public function deletar($nomeArquivo){
        $this->db->where('nome',$nomeArquivo);
        if($this->db->delete('arquivos')){
          redirect('home/teste');
        }
     }
     
    
}
