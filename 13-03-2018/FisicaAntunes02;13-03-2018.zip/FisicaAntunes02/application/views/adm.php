<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>Física Antunes</title>
    <link href="http://localhost/FisicaAntunes02/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="http://localhost/FisicaAntunes02/assets/jquery-3.2.0.min.js"  type="text/javascript"></script>
    <script src="http://localhost/FisicaAntunes02/assets/bootstrap/js/bootstrap.min.js"  type="text/javascript"></script>
	 <link href="http://localhost/FisicaAntunes02/assets/css/estilosADM.css" rel="stylesheet">
    
    <?php
  $var = 2;
  if($var == "1"){
echo '<script> $(document).ready(function(){
            $("#escondida").modal();
        });
    </script>';
  }
?>
</head>

<body> 
    	<div id="topo">
			<div id="logo">
				<img id="logoCefet" src="http://localhost/FisicaAntunes02/assets/images/logo.jpg"> 
			</div>
			<div id="titulo">
				<p id="titulo1">Pedro Antunes Duarte, MSc</p>
			</div>
		</div>
	<input type="checkbox" id="check">
  			<label for="check">&#9776;</label>
    	<div id="meenu">
        	<nav id="menunav">
        		<div id="center">
        	    <ul id="menu" class="nav nav-tabs">
        	        <li>
        	            <form action="http://localhost/FisicaAntunes02/home"><button id="menuu" type="submit" class="btn btn-default navbar-btn"><b>Home</b></button></form>
        	         </li>                        
                    	<li>
                     		<a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" id="menuu">Graduação<span class="caret"></span></a>
                    		<ul id="menuuu" class="dropdown-menu">
                          		<?php 
									foreach($disciplinas as $disciplina){
                        				?>
                        				<li>
                          	 				<?php 
												echo anchor(base_url("disciplina/disciplina/".$disciplina->nome),'<span id="drop">' . $disciplina->nome . '</span>');
                          	 				?>
                        				</li>
                          				<?php
                          					}
                        				?>
                     		</ul> 
                    	</li>
                    	<li>
                     		<a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" id="menuu">Técnicos<span class="caret"></span></a>
                     		<ul id="menuuu" class="dropdown-menu">
                          		<?php 
									foreach($tecnicos as $tecnico){
                        	  ?>
                  			   <li>
                           	 <?php echo anchor(base_url("tecnico/tecnico/".$tecnico->nomeTecnico),'<span id="drop">' . $tecnico->nomeTecnico. '</span>');
                           	 ?> 
                          		</li>
                       
                         				<?php
                          					}
                        				?>
                     		</ul> 
                    	</li>
                     <li>
                        <form action="http://localhost/FisicaAntunes02/evento"><button id="menuu" type="submit" class="btn btn-default navbar-btn"><b>Eventos</b></button></form>
                     </li>
                    	<li>
    <?php if($this->session->userdata('logado') == 'TRUE'){
           $subADM = array('class' => 'btn btn-default dropdown-toggle','id' => 'menuu');
           echo form_open(base_url("adm")) .
                form_submit('nomequalquer','Administração',$subADM).
                form_close();
         }else{
          ?>
<button type="button" class="btn btn-default navbar-btn" id="menuu" data-toggle="modal" data-target="#loginADM">Administração</button>
           	<div class="modal fade" id="loginADM" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            	<div class="modal-dialog" role="document">
            	    <div class="modal-content">
            	        <div class="modal-header">
            	            <h4 class="modal-title" id="exampleModalLabel02">Para permissões administrativas, insira sua senha:</h4>
            	        </div>
            	        <div class="modal-body">
           		            <div class="form-group">
           		                <?php
                                $infoss = array('class' => 'form-label');
          		                $info = array('class' => 'form-control');
          		                $infos = array('class' => 'btn btn-default dropdown-toggle','id' => 'botao');
	      		                   echo form_open(base_url("adm/login")) .
          		                    form_label("Senha: " ,"txt_senha",$infoss).br() .
                                       form_input("txt_camposenha",'',$info) . br().
                                       form_submit('nomequalquer','Enviar Mensagem',$infos).
                                       form_close();
            	                ?>
            	            </div>
            	        </div>  
            	    </div>
            	</div>
        	</div>
     <?php
         }
     ?>





                          
                    	</li>
                    	<li>   
                        	<button type="button" class="btn btn-default navbar-btn" id="menuu" data-toggle="modal" data-target="#exampleModal"><b>Contato</b></button> 
                    	</li> 
							<li>
<button type="button" class="btn btn-default navbar-btn" id="menuuL" data-toggle="modal" data-target="#logoutADM">Logout</button>
           	<div class="modal fade bd-example-modal-sm" id="logoutADM" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            	<div id="logoutD" class="modal-dialog modal-sm" role="document">
            	    <div class="modal-content">
            	        <div class="modal-header">
            	            <h4 class="modal-title" id="exampleModalLabel02">Deseja fazer o Logout?</h4>
            	        </div>
            	        <div class="modal-body">
           		            <div class="form-group">
           		                <?php
          		                $infos = array('class' => 'btn btn-default dropdown-toggle','id' => 'botao');
	      		                   echo form_open(base_url("adm/logout")) .
                                       form_submit('nomequalquer','OK',$infos).
                                       form_close();
            	                ?>
            	            </div>
            	        </div>  
            	    </div>
            	</div>
        	</div>
                 </li>  
            	</ul>  
        	</nav>
			<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
	            <div class="modal-dialog" role="document">
	                <div class="modal-content">
	                    <div class="modal-body">
          
             Telefones (CEFET - Formação Geral): (35) 3690-4216  <br>
                                                (35) 3690-4214  <br>
                                                (35) 3690-4234  <br>
             Email: pedroantunes.pd@gmail.com <br>
                    antunes.pd@gmail.com
        
	                    </div>
	                </div>
	            </div>
	        </div>
	      </div>
	
	
	
	
	
	
	



















		
			<div id="conteudoADM">
			<div id="tituloConteudoADM">
				<h2 id="tituloConteudoADM1">Arquivos das Disciplinas</h2>	
				<h2 id="tituloConteudoADM2">Arquivos dos Técnicos</h2>		
			</div>
				<div id="info">
					<div id="tabela1"> 
 						<table id="tabel"> 
 						<tr>
							<pid="correcao1"></p> 						
 						</tr>
  			<?php    
    			foreach($arquivosDisciplina as $arquivoDisciplina){
    		?>
     		<tr>

      		<td id="tdArquivo">
  					<?php  
          			$submitDownload = array('content'=>" ".$arquivoDisciplina->nomeArquivo,'name'=>'nomeArquivo','type'=>'submit','value'=>$arquivoDisciplina->nomeArquivo,'class'=>'glyphicon glyphicon-cloud-download','id'=>'arqDownload'); 
     					echo form_open_multipart("disciplina/download").
          form_button($submitDownload). 
          form_hidden('campo_nomeArquivo',$arquivoDisciplina->nomeArquivo).
          form_hidden('campo_idDisciplina',$arquivoDisciplina->idDisciplina).
          form_close();
    
     				?>
      		</td>

      		<td id="tdExcluirArquivo">
           <input type="image" src="http://localhost/FisicaAntunes02/assets/images/excluir2.png"  id="excluirArquivo1" data-toggle="modal"  
        data-target="#<?php echo md5(sha1($arquivoDisciplina->idArquivo.'arquivosDisciplina'));?>">
  <div class="modal fade" id="<?php echo md5(sha1($arquivoDisciplina->idArquivo.'arquivosDisciplina'));?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Excluir Arquivo</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                               echo "Deseja realmente excluir esse arquivo da Disciplina?";
          		               $submitExcluir = array('name'=>'oculto','id'=>'Excl','value'=>'Excluir','class'=>'btn btn-default navbar-btn');
      				           echo form_open_multipart('disciplina/deletarArquivoDisciplina').
                             form_submit($submitExcluir).
                             form_hidden('campo_idDisciplina',$arquivoDisciplina->idDisciplina).
                             form_hidden('campo_nomeArquivo',$arquivoDisciplina->nomeArquivo).
                             form_close();
                            ?>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
     			</td>

     		</tr>
                            
   		<?php 
    			}
   		?> 
		</table>
	</div>

	<div id="tabela2">
			<table id="tabel">  
                <tr>
				<pid="correcao"></p> 						
 			</tr>
 				<h5>Arquivos 1º Bimestre</h5>
  				<?php    
    				foreach($arquivosTecnico as $arquivoTecnico){
    			?>
     			<tr>                
      			   <td>
                     <?php 
               if($arquivoTecnico->bimestre == '1') {        
                     $submitDownload = array('content'=>" ".$arquivoTecnico->nomeArquivo,'name'=>'nomeArquivo','type'=>'submit','value'=>$arquivoTecnico->nomeArquivo,'class'=>'glyphicon glyphicon-cloud-download','id'=>'arqDownload'); 
     					echo form_open_multipart("tecnico/download").
          			form_hidden('campo_nomeArquivo',$arquivoTecnico->nomeArquivo).
         			form_hidden('campo_idTecnico',$arquivoTecnico->idTecnico).
			 			form_hidden('bimestre',$arquivoTecnico->bimestre).
					   form_button($submitDownload). 
         		   form_close();  
       ?>		
      	</td>


      	<td id="tdExcluirArquivo">
<input type="image" src="http://localhost/FisicaAntunes02/assets/images/excluir2.png"  id="excluirArquivo1" data-toggle="modal"  
        data-target="#<?php echo sha1(md5($arquivoTecnico->idArquivo.'arquivosTecnico'));?>">
  <div class="modal fade" id="<?php echo sha1(md5($arquivoTecnico->idArquivo.'arquivosTecnico')) ;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Excluir Arquivo</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                               echo "Deseja realmente excluir esse arquivo do Técnico?";
          		               $submitExcluir = array('name'=>'oculto','value'=>'Excluir','class'=>'btn btn-default navbar-btn');
      				           echo form_open_multipart('tecnico/deletarArquivoTecnico').
                             form_hidden('campo_nomeArquivo',$arquivoTecnico->nomeArquivo).    
                             form_hidden('campo_idTecnico',$arquivoTecnico->idTecnico).
									  form_hidden('bimestre',$arquivoTecnico->bimestre).
									  form_submit($submitExcluir).
                             form_close();
                            ?>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
     				</td>
<td>
						<?php
							  foreach($tecnicos as $tecnico){
									if($tecnico->idTecnico == $arquivoTecnico->idTecnico){
											echo $tecnico->nomeTecnico;
									}
							  } 
						?>
					</td>

     			</tr>
            
   			<?php 
   				}
    			}
    			?> 
    	</table>	
    	<table id="tabel">  
    			<h5>Arquivos 2º Bimestre</h5>
    			<?php    
    				foreach($arquivosTecnico as $arquivoTecnico){
    			?>
    		
     			<tr>                
      			   <td>
                     <?php 
               if($arquivoTecnico->bimestre == '2') {        
                     $submitDownload = array('content'=>" ".$arquivoTecnico->nomeArquivo,'name'=>'nomeArquivo','type'=>'submit','value'=>$arquivoTecnico->nomeArquivo,'class'=>'glyphicon glyphicon-cloud-download','id'=>'arqDownload'); 
     					echo form_open_multipart("tecnico/download").
          			form_hidden('campo_nomeArquivo',$arquivoTecnico->nomeArquivo).
         			form_hidden('campo_idTecnico',$arquivoTecnico->idTecnico).
			 			form_hidden('bimestre',$arquivoTecnico->bimestre).
					   form_button($submitDownload). 
         		   form_close();  
       ?>		
      	</td>


      	<td id="tdExcluirArquivo">
<input type="image" src="http://localhost/FisicaAntunes02/assets/images/excluir2.png"  id="excluirArquivo1" data-toggle="modal"  
        data-target="#<?php echo sha1(md5($arquivoTecnico->idArquivo.'arquivosTecnico'));?>">
  <div class="modal fade" id="<?php echo sha1(md5($arquivoTecnico->idArquivo.'arquivosTecnico')) ;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Excluir Arquivo</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                               echo "Deseja realmente excluir esse arquivo do Técnico?";
          		               $submitExcluir = array('name'=>'oculto','value'=>'Excluir','class'=>'btn btn-default navbar-btn');
      				           echo form_open_multipart('tecnico/deletarArquivoTecnico').
                             form_hidden('campo_nomeArquivo',$arquivoTecnico->nomeArquivo).    
                             form_hidden('campo_idTecnico',$arquivoTecnico->idTecnico).
									  form_hidden('bimestre',$arquivoTecnico->bimestre).
									  form_submit($submitExcluir).
                             form_close();
                            ?>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
     				</td>
<td>
						<?php
							  foreach($tecnicos as $tecnico){
									if($tecnico->idTecnico == $arquivoTecnico->idTecnico){
											echo $tecnico->nomeTecnico;
									}
							  } 
						?>
					</td>

     			</tr>
   			<?php 
   				}
    			}
    			?> 
    			</table>
    			
    			<table id="tabel">  
    			<h5>Arquivos 3º Bimestre</h5>
    			<?php    
    				foreach($arquivosTecnico as $arquivoTecnico){
    			?>
    			
     			<tr>                
      			   <td>
                     <?php 
               if($arquivoTecnico->bimestre == '3') {        
                     $submitDownload = array('content'=>" ".$arquivoTecnico->nomeArquivo,'name'=>'nomeArquivo','type'=>'submit','value'=>$arquivoTecnico->nomeArquivo,'class'=>'glyphicon glyphicon-cloud-download','id'=>'arqDownload'); 
     					echo form_open_multipart("tecnico/download").
          			form_hidden('campo_nomeArquivo',$arquivoTecnico->nomeArquivo).
         			form_hidden('campo_idTecnico',$arquivoTecnico->idTecnico).
			 			form_hidden('bimestre',$arquivoTecnico->bimestre).
					   form_button($submitDownload). 
         		   form_close();  
       ?>		
      	</td>


      	<td id="tdExcluirArquivo">
<input type="image" src="http://localhost/FisicaAntunes02/assets/images/excluir2.png"  id="excluirArquivo1" data-toggle="modal"  
        data-target="#<?php echo sha1(md5($arquivoTecnico->idArquivo.'arquivosTecnico'));?>">
  <div class="modal fade" id="<?php echo sha1(md5($arquivoTecnico->idArquivo.'arquivosTecnico')) ;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Excluir Arquivo</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                               echo "Deseja realmente excluir esse arquivo do Técnico?";
          		               $submitExcluir = array('name'=>'oculto','value'=>'Excluir','class'=>'btn btn-default navbar-btn');
      				           echo form_open_multipart('tecnico/deletarArquivoTecnico').
                             form_hidden('campo_nomeArquivo',$arquivoTecnico->nomeArquivo).    
                             form_hidden('campo_idTecnico',$arquivoTecnico->idTecnico).
									  form_hidden('bimestre',$arquivoTecnico->bimestre).
									  form_submit($submitExcluir).
                             form_close();
                            ?>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
     				</td>
<td>
						<?php
							  foreach($tecnicos as $tecnico){
									if($tecnico->idTecnico == $arquivoTecnico->idTecnico){
											echo $tecnico->nomeTecnico;
									}
							  } 
						?>
					</td>

     			</tr>
   			<?php 
   				}
    			}
    			?> 
    			</table>
    			
    			
    			
    			<table id="tabel">  
    			<h5>Arquivos 4º Bimestre</h5>
    			<?php    
    				foreach($arquivosTecnico as $arquivoTecnico){
    			?>
    			
     			<tr>                
      			   <td>
                     <?php 
                     
               if($arquivoTecnico->bimestre == '4') {        
                     $submitDownload = array('content'=>" ".$arquivoTecnico->nomeArquivo,'name'=>'nomeArquivo','type'=>'submit','value'=>$arquivoTecnico->nomeArquivo,'class'=>'glyphicon glyphicon-cloud-download','id'=>'arqDownload'); 
     					echo form_open_multipart("tecnico/download").
          			form_hidden('campo_nomeArquivo',$arquivoTecnico->nomeArquivo).
         			form_hidden('campo_idTecnico',$arquivoTecnico->idTecnico).
			 			form_hidden('bimestre',$arquivoTecnico->bimestre).
					   form_button($submitDownload). 
         		   form_close();  
       ?>		
      	</td>


      	<td id="tdExcluirArquivo">
<input type="image" src="http://localhost/FisicaAntunes02/assets/images/excluir2.png"  id="excluirArquivo1" data-toggle="modal"  
        data-target="#<?php echo sha1(md5($arquivoTecnico->idArquivo.'arquivosTecnico'));?>">
  <div class="modal fade" id="<?php echo sha1(md5($arquivoTecnico->idArquivo.'arquivosTecnico')) ;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Excluir Arquivo</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                               echo "Deseja realmente excluir esse arquivo do Técnico?";
          		               $submitExcluir = array('name'=>'oculto','value'=>'Excluir','class'=>'btn btn-default navbar-btn');
      				           echo form_open_multipart('tecnico/deletarArquivoTecnico').
                             form_hidden('campo_nomeArquivo',$arquivoTecnico->nomeArquivo).    
                             form_hidden('campo_idTecnico',$arquivoTecnico->idTecnico).
									  form_hidden('bimestre',$arquivoTecnico->bimestre).
									  form_submit($submitExcluir).
                             form_close();
                            ?>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
     				</td>
					<td>
						<?php
							  foreach($tecnicos as $tecnico){
									if($tecnico->idTecnico == $arquivoTecnico->idTecnico){
											echo $tecnico->nomeTecnico;
									}
							  } 
						?>
					</td>

     			</tr>
   			<?php 

   				}
    			}
    			?> 
			</table>
        </div>

<div id="ragnarok">
<hr>
	<div id="tituloMTabela">
				<h2 id="tituloConteudoADM1">Disciplinas</h2>	
				<h2 id="tituloConteudoADM2">Técnicos</h2>	
				<p id="correcao1">.</p>	
				</div>
				<div id="tabela10">
                <table id="tabel">
                        <?php
                          foreach($disciplinas as $disciplina){
                        ?>
                        <tr>
                         <td id="tdNome">
                           <?php

                               $info = array('name'=>sha1(md5($disciplina->idDisciplina)),'value'=>$disciplina->nome,'class' => 'form-control','id'=>'nome');
	      		                  
                               
                             $submitRenomear = array('type'=>'image','name'=>'renomearDisciplina','class'=>'glyphicon glyphicon-pencil','id'=>'renomear');
                             echo form_open('disciplina/renomearDisciplina').
                                  form_hidden('campo_idDisciplina',$disciplina->idDisciplina).
                                  form_input($info);
       
                                 
                                     
                           ?>
                             <?php 
                                 echo form_button($submitRenomear).
                                  form_close();
                             ?>
                            
                                  
                             
       <input type="image" src="http://localhost/FisicaAntunes02/assets/images/excluir2.png"  id="excluirArquivo2" data-toggle="modal" 
        data-target="#<?php echo sha1(md5($disciplina->idDisciplina.'disciplina'));?>">
  <div class="modal fade" id="<?php echo sha1(md5($disciplina->idDisciplina.'disciplina'));?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Excluir Disciplina:</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                              echo "Deseja realmente excluir essa disciplina?";
          		               $submitExcluir = array('name'=>'ex','id'=>'exc','value'=>'Excluir','class'=>'btn btn-default navbar-btn');
      				           echo form_open_multipart('disciplina/deletarDisciplina').
                             form_hidden('campo_idDisciplina',$disciplina->idDisciplina).
                             form_submit($submitExcluir).
                             form_close();
                            ?>
                        </div>
                    </div>  
                </div>
            </div>
        </div> 
 
                         </td>
                          <td>
                              <p id="upload"> Upload dos arquivos: </p>
                            <?php
                              $addUpload = array('name' => 'arquivo','value' => 'Arquibao',
                                         'type'=>'file','class'=>'btn btn-default navbar-btn','id'=>'arqUpload');     
    									$addSubmit = array('name' => 'dcsd','type'=>'submit', 'value'=> 'true', 'content'=> 'Enviar', 'class'=>'btn btn-default navbar-btn');   

    									echo form_open_multipart("disciplina/verificaDisciplina").
         							form_upload($addUpload).
                              form_hidden('campo_idDisciplina',$disciplina->idDisciplina).
                              form_button($addSubmit). 
                             
         							form_close();
    								 ?>

                         </td>
                         </tr>
                          <?php
                          }
                        ?>
									<tr>
								        <td>
											<button type="button" class="btn btn-default navbar-btn" id="cadastrar" data-toggle="modal" data-target="#cadastrarDisciplina"><b>Cadastrar Disciplina</b></button>
  <div class="modal fade" id="cadastrarDisciplina" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Nova disciplina:</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                                
          		                $info = array('class' => 'form-control');
          		                $infos = array('class' => 'btn btn-default dropdown-toggle','id' => 'botao');
	      		                   echo form_open(base_url("disciplina/cadastroDisciplina")) .
                                       form_input("nomeDisciplina",'',$info) . br().
                                       form_submit('nomequalquer','Cadastrar',$infos).
                                       form_close();
                            ?>
                        </div>
                    </div>  
                </div>
            </div>
        </div>										
            </td>									
				</tr>
       </table>  
</div>
      





   <div id="tabela20">
   <table id="tabel">
                        <?php
                          foreach($tecnicos as $tecnico){
                        ?>
                        <tr>
                         <td id="tdNome">
                           <?php
                              $submitRenomear = array('type'=>'image','name'=>$tecnico->idTecnico,'class'=>'glyphicon glyphicon-pencil','id'=>'renomear');
                               $info = array('class' => 'form-control','id'=>'nome');
	      		                   echo form_open('tecnico/renomearTecnico').
                                       form_input("novoNome",$tecnico->nomeTecnico,$info).
                                       form_hidden('campo_idTecnico',$tecnico->idTecnico);
                                      
                           ?> 
                             <?php 
                              echo form_button($submitRenomear).
                                   form_close();
                             ?> 
<input type="image" src="http://localhost/FisicaAntunes02/assets/images/excluir2.png"  id="excluirArquivo2" data-toggle="modal" 
        data-target="#<?php echo sha1(md5($tecnico->idTecnico.'tecnico'));?>">
    
  <div class="modal fade" id="<?php echo sha1(md5($tecnico->idTecnico.'tecnico'));?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Excluir Técnico</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                               echo "Deseja realmente excluir esse técnico?";
          		               $submitExcluir = array('name'=>'oculto','value'=>'Excluir','class'=>'btn btn-default navbar-btn');
      				           echo form_open_multipart('tecnico/deletarTecnico').
                             form_submit($submitExcluir).
                             form_hidden('campo_idTecnico',$tecnico->idTecnico).
                             form_close();
                            ?>
                        </div>
                    </div>  
                </div>
            </div>
        </div>


 
                         </td>


                          <td>
                              <p id="upload"> Upload dos arquivos: </p>
                            <?php
                              $addUpload = array('name' => 'arquivo','value' => 'Arquibao',
                                         'type'=>'file','class'=>'btn btn-default navbar-btn','id'=>'arqUpload');     
    									$addSubmit = array('name' => 'submit','value' => 'Enviar','class'=>'btn btn-default navbar-btn', 'id'=>'enviar');  
$addRadio1 = array('name'=>'bimestre','checked'=> TRUE, 'value'=> '1');
$addRadio2 = array('name'=>'bimestre','checked'=> FALSE, 'value'=> '2');
$addRadio3 = array('name'=>'bimestre','checked'=> FALSE, 'value'=> '3');
$addRadio4 = array('name'=>'bimestre','checked'=> FALSE, 'value'=> '4');  
    									echo form_open_multipart("tecnico/verificaTecnico").
         							form_upload($addUpload).
                              form_hidden('campo_idTecnico',$tecnico->idTecnico).
                              form_radio($addRadio1).
                              form_radio($addRadio2).
                              form_radio($addRadio3).
                              form_radio($addRadio4).
                              form_submit($addSubmit). 
         							form_close();
    								 ?>
                              <!--<p id="bimestre">1°</p>
                              <p id="bimestre">2°</p>
                              <p id="bimestre">3°</p>
                              <p id="bimestre">4°</p>-->
                         </td>


                         </tr>
                          <?php
                          }
                        ?>
                        <tr>
										<td>
											<button type="button" class="btn btn-default navbar-btn" id="cadastrar" data-toggle="modal" data-target="#cadastrarTecnico"><b>Cadastrar Técnico</b></button>
  <div class="modal fade" id="cadastrarTecnico" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Novo Técnico:</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                                
          		                $info = array('class' => 'form-control');
          		                $infos = array('class' => 'btn btn-default dropdown-toggle','id' => 'botao');
	      		                   echo form_open(base_url("tecnico/cadastroTecnico")) .
                                       form_input("nomeTecnico",'',$info) . br().
                                       form_submit('nomequalquer','Cadastrar',$infos).
                                       form_close();
                            ?>
                        </div>
                    </div>  
                		</div>
            		</div>
        			</div>										
										</td>                        
                        </tr>
      		</table> 
      	</div>
      </div>
	</div>

	<div id="tituloEventosADM">
            <h2 id="tituloEventosADM1">Eventos</h2>
        </div>
    <div id="eventos">
 <?php 
                 foreach($eventos as $evento){
             ?>  

      <div class="evento">
                   <input  id="eventoButton" type="image" src="http://localhost/FisicaAntunes02/uploads/eventos/<?php echo $evento->idEvento;?>"  class="btn btn-default navbar-btn" id="eventoButton" 
                  data-toggle="modal" data-target="#<?php echo md5(sha1($evento->idEvento));?>" >


        <div class="modal fade" id="<?php echo md5(sha1($evento->idEvento));?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Evento:</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                             $alterar = array('value'=>'Salvar Alterações');
                             $c = array('name'=>'conteudoEvento','value'=>$evento->conteudoEvento,'id'=>'conteudoEvento');
                         echo form_open_multipart("evento/alterarEvento").
                              form_textarea($c). 
                              form_hidden('campo_idEvento',$evento->idEvento).
                              form_submit($alterar). 
         							form_close()      
    								 ?>
                           <?php
                             $excluir = array('value'=>'Excluir');
                         echo form_open_multipart("evento/excluirEvento").
                              form_hidden('campo_idEvento',$evento->idEvento).
                              form_submit($excluir). 
         							form_close()      
    								 ?>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
			</div>
           <?php 
                 }
            ?> 
 			<div id="correcao2">
 <?php 
    $dados = array('class'=>'btn btn-default navbar-btn1','data-toggle'=>'modal', 
            'data-target'=>'#cadastrarevento','content'=>'Cadastrar Evento','id'=>'cadastrarE');
    echo form_button($dados);
 ?>
			</div>
			<div class="modal fade" id="cadastrarevento" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Evento:</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                              $addUpload = array('name' => 'arquivo','value' => 'Arquibao',
                                         'type'=>'file','class'=>'btn btn-default navbar-btn');     
    									$addSubmit = array('name' => 'dcsd', 'value'=> 'Cadastrar', 'content'=> 'Teste');
                              $addTextArea = array('name'=>'conteudoEvento');    
    									echo form_open_multipart("evento/cadastrarEvento").
         							form_upload($addUpload).
                              form_textarea($addTextArea).
                              form_submit($addSubmit). 
         							form_close();
    								 ?>
                         
                            </div>
                        </div>  
                    </div>
                </div>
            </div>  
	       </div>
        </div>
        </div>
            <img id="invisivel" src="http://localhost/FisicaAntunes02/assets/images/invisivel.png">
            <!--<img id="Einsten"src="http://localhost/FisicaAntunes02/assets/images/Einsten.jpg">-->
            <div id="rodape">
                <p id="rodapeC">&copy; CEFET-MG Unidade VIII | all rights reserved</p>
                <!--<p id="nRodape">Projeto Física Antunes</p>
                <p id="dRodape">Desenvolvedores:<br> Edgard Alexandre e Willian Alves</p>
                <p id="fRodape">"A imaginação é mais importante que o conhecimento."</p>
                <span id="raio" class="glyphicon glyphicon-flash"></span>
                <span id="fogo" class="glyphicon glyphicon-fire"></span>
                <span id="folha" class="glyphicon glyphicon-leaf"></span>
                <span id="gota" class="glyphicon glyphicon-tint"></span>
                <p id="contatoC">Dados da Instituição:</p>
                <p id="contatoCefet">Telefone: +55 (35) 3690-4200 <br> Endereço: Avenida dos Imimgrantes, 1000 <br> Bairro Vargem, Varginha - MG - Brasil <br> CEP: 37.022-560</p>-->
            </div>
            <div id="rodape2">rodape</div>
    </div>
 </body>
</html>
