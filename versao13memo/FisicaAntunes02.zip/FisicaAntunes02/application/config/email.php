<?php
 defined('BASEPATH') OR exit('No direct script access allowed');
 $config['protocol'] = 'smtp';
 $config['smtp_host'] = 'ssl ://smtp.googlemail.com';
 $config['smtp_port'] = '465';
 $config['smtp_timeout'] = '60';
 $config['smtp_user'] = 'willianalvesalmeida741@gmail.com';
 $config['smtp_pass'] = '456456456456';
 $config['validate']  = TRUE;
 $config['charset'] = 'utf-8';
 $config['newline'] = "\r\n" ;
 $config['mailtype'] = 'html';