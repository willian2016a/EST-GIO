<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Model {
        function __construct() {
           parent::__construct();
           $this->load->library('session');
        }

        public function verificacao($x){
             //obter os dados que vêm do banco na tabela login
                 $query = $this->db->query('SELECT id,senha FROM login');
                 foreach ($query->result_array() as $row){
            		$id = $row['id'];
            		$senha = $row['senha'];
           		    
                 }
               if($x == $senha){
                  $array = array("logado"=>TRUE);
				  $this->session->set_userdata($array);
                  redirect("home");
                }else{
                  $this->session->sess_destroy();
                  redirect("home");
                }


        }
}
