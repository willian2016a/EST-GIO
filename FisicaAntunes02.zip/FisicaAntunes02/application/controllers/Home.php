<?php   defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->helper('download');
        $this->load->helper('form');
    }

	public function index(){
		$this->load->view('home');	
	}	

    public function login(){
        $this->load->model('Login','',TRUE); 
        $usuario = $this->input->post('txt_camposenha');
        $this->Login->verificacao($usuario);  
       
    }

    public function graduacao(){
     //verifica se o usuario logou.Views usadas sao inexistentes
      if(!$this->session->userdata('logado')){
         $this->load->view('Y');
      }else{
         $this->load->view('X');
      }
    }

    public function teste(){
        $this->load->view('teste');	
    }

     public function download(){
         //da forma baixo n está funcionando,porém n compreendo o pq:
         //$arquivo = $this->input->post("txt_upteste");
        
         //desta forma funciona ,porém n é viável por ser estático:
         $arquivo = 'aplicacoesweb.pdf';
         $path = file_get_contents(base_url()."/uploads/".$arquivo);
         force_download($nome, $path);
    }



 public function salvar(){  
    $arquivo = $_FILES['arquivo'];
    $configuracao = array(
        'upload_path'   => './uploads/',
        'allowed_types' => 'jpg|png|gif|pdf|zip|rar|doc|xls',
        'max_size'      => '2000'
    );      
    $this->load->library('upload');
     $this->upload->initialize($configuracao);
     if($this->upload->do_upload('arquivo')){
         echo 'Arquivo salvo com sucesso.';
     }else{
        echo $this->upload->display_errors();
       }
}

}

