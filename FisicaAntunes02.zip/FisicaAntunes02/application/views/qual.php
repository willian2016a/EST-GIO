<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>Física Antunes</title>
    <link href="http://localhost/FisicaAntunes02/assets/css/estilos.css" rel="stylesheet">
    <link href="http://localhost/FisicaAntunes02/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="http://localhost/FisicaAntunes02/assets/jquery-3.2.0.min.js"  type="text/javascript"></script>
    <script src="http://localhost/FisicaAntunes02/assets/bootstrap/js/bootstrap.min.js"  type="text/javascript"></script>
   
    
</head>
<body>
<form action="salvar" method="POST" enctype="multipart/form-data">
    <input type="file" name="curriculo">
       <br/>
    <input type="submit" value="Salvar"/>
 </form>
  <?php
     
    echo form_open() .
	     form_input('nomequalquer','aplicacoesweb.pdf').
		 form_close();



    echo form_input("txt_camposenha");
   echo anchor(base_url('home/Down'),'DOWNLOAD');

 ?>   
   
</body>
</html>
