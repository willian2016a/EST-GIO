<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>Física Antunes</title>
    <link href="http://localhost/FisicaAntunes02/assets/css/estilos.css" rel="stylesheet">
    <link href="http://localhost/FisicaAntunes02/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="http://localhost/FisicaAntunes02/assets/jquery-3.2.0.min.js"  type="text/javascript"></script>
    <script src="http://localhost/FisicaAntunes02/assets/bootstrap/js/bootstrap.min.js"  type="text/javascript"></script>
    
</head>
<body>

<div>
    <h3>Informações do arquivo</h3>
    <?php 
        foreach($dadosArquivo as $key => $value):
            if($value): 
    ?>
                <strong><?=$key?></strong>: <?=$value?>
    <?php 
            endif; 
        endforeach;
    ?>
    <hr />
    <a href="<?=base_url()?>" >Novo arquivo</a>
    <a href="<?=$urlDownload?>">Download</a>
</div>
   

   
</body>
</html>
