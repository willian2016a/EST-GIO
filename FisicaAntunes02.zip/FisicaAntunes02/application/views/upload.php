<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>Física Antunes</title>
    <link href="http://localhost/FisicaAntunes02/assets/css/estilos.css" rel="stylesheet">
    <link href="http://localhost/FisicaAntunes02/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="http://localhost/FisicaAntunes02/assets/jquery-3.2.0.min.js"  type="text/javascript"></script>
    <script src="http://localhost/FisicaAntunes02/assets/bootstrap/js/bootstrap.min.js"  type="text/javascript"></script>
    
</head>
<body>
<div>
    <?php if(isset($error)):?>
        <div><?=$error?></div>
    <?php endif; ?>

    <form action="<?=base_url('home/Upload')?>" method="POST" enctype="multipart/form-data">
        <div>
            <label>Selecione um arquivo (zip, rar, pdf, doc, xls, jpg, png, gif)</label>
            <input type="file" name="arquivo"/>
        </div>
        <div>
            <input type="submit" value="Processar" />
        </div>
    </form>
</div>

   

   
</body>
</html>
