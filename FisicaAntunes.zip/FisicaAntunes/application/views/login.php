<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title>LOGIN</title>
     <link href="http://localhost/FisicaAntunes/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="http://localhost/FisicaAntunes/assets/jquery-3.2.0.min.js"  type="text/javascript"></script>
    <script src="http://localhost/FisicaAntunes/assets/bootstrap/js/bootstrap.min.js"  type="text/javascript"></script>
</head>
<body>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Open modal for @mdo</button>
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">New message</h4>
      </div>
      <div class="modal-body">
        <form>
          <div class="form-group">
            <label for="recipient-name" class="control-label">Recipient:</label>
            <input type="text" class="form-control" id="recipient-name">
          </div>
          <div class="form-group">
            <label for="message-text" class="control-label">Message:</label>
            <textarea class="form-control" id="message-text"></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Send message</button>
      </div>
    </div>
  </div>
</div>
<?php
	$atributos = array('name'=>'formulario_contato','id'=>'formulario_contato');
	echo form_open(base_url('home/enviar_mensagem') , $atributos) .
	form_label("Nome: " ,"txt_nome").br() .
	form_input('txt_nome') . br().
	form_submit("btn_enviar" ,"Enviar Mensagem").
	form_close();
?>
</body>
</html>
