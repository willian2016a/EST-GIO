<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title>LOGIN</title>
</head>
<body>
    sucesso!!
</body>
</html>
