<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper('form');
        $this->load->library('session');
    }

	public function index(){
		$this->load->view('home');	
	}	
    
    public function funcao(){
        $this->load->view('x');
    }

    public function login(){
        $this->load->view('login');
    }
     public function x(){
        $this->load->view('x');
    }
    public function antisucesso(){
        $this->load->view('antisucesso');
    }
    public function enviar_mensagem(){
        $usuario = $this->input->post('txt_camposenha');
        if($usuario == 123){
            $this->load->library('session');
            $array = array("logado" =>TRUE);
			$this->session->set_userdata($array);
			redirect("home/x");
        }else{
            redirect("home/antisucesso");
        }
       
    }
}
