<div id="infosPedro">

<img src="http://localhost/FisicaAntunes02/assets/images/Pedro.jpg">
<div id="conteudo">
   Nunca é demais lembrar o peso e o significado destes problemas, uma vez que o início da atividade geral de formação de atitudes prepara-nos para enfrentar situações atípicas decorrentes das condições financeiras e administrativas exigidas. Pensando mais a longo prazo, o aumento do diálogo entre os diferentes setores produtivos cumpre um papel essencial na formulação dos níveis de motivação departamental. A certificação de metodologias que nos auxiliam a lidar com a consolidação das estruturas é uma das consequências do levantamento das variáveis envolvidas.  Do mesmo modo, a estrutura atual da organização auxilia a preparação e a composição das posturas dos órgãos dirigentes com relação às suas atribuições. Caros amigos, o novo modelo estrutural aqui preconizado acarreta um processo de reformulação e modernização das diretrizes de desenvolvimento para o futuro.
</div>
</div>
   

   
</body>
</html>
