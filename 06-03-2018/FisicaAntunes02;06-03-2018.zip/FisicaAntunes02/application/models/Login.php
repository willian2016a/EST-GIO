<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Model {
        function __construct() {
           parent::__construct();
          
        }

        public function verificacao($x){
             //obter os dados que vêm do banco na tabela login
                 $query = $this->db->query('SELECT senha FROM login');
                 foreach ($query->result_array() as $row){
            		$senha = $row['senha']; 
                 }
               if($x == $senha){
                  $this->load->library('session');
                  $array = array("logado"=>TRUE);
				      $this->session->set_userdata($array);
                  redirect("adm");
                }else{
                  redirect("home");
                }
        }

			public function logout(){
                  $array = array("logado"=>FALSE);
				      $this->session->set_userdata($array);
                  redirect("home");
			}
}
