<div id="infosPedro">

<img src="http://localhost/FisicaAntunes02/assets/images/Pedro.jpg">
<div id="conteudo">
   Professor do Quadro Efetivo no Centro Federal de Educação Tecnológica de Minas Gerais - CEFET/MG Varginha, Graduado em Física pela UNIFOR/MG, Mestre em Ciências - Materiais para Engenharia pela Universidade Federal de Itajubá - UNIFEI, atualmente é aluno de doutorado do Programa Petrobras de Formação de Recursos Humanos - PFRH no Instituto de Engenharia Mecânica da UNIFEI e Tesoureiro do UNIFEI Student Chapter da SPE - Society of Petroleum Engineers, atua em áreas relacionadas à Ensino de Física, Energia, Petróleo e Materiais para Engenharia. Dedica-se a estudar a influência dos processos de soldagem na microestrutura, nas propriedades mecânicas, de corrosão e de desgaste em materiais de engenharia voltados para a indústria de petróleo através do uso de técnicas experimentais.
</div>
</div>
   

   
</body>
</html>
