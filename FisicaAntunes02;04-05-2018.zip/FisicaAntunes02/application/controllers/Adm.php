<?php   defined('BASEPATH') OR exit('No direct script access allowed');

class Adm extends CI_Controller {
    function __construct() {
        parent::__construct();
       /* $this->load->helper('file');
        $this->load->helper('download');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->library('upload'); 
       */
        $this->load->helper('string'); 
 
       
    }

    public function index(){
    	 $this->load->helper('string'); 
      if($this->session->userdata('logado') == 'TRUE'){
        $this->load->model('Disciplinas','',TRUE); 
        $this->load->model('Tecnicos','',TRUE); 
        $this->load->model('Eventos','',TRUE);  
        $conteudo['eventos'] = $this->Eventos->listarEventos();
        $conteudo['arquivosTecnico'] = $this->Tecnicos->arquivosTecnico();
        $conteudo['tecnicos'] = $this->Tecnicos->listarTecnicos();
        $conteudo['arquivosDisciplina'] = $this->Disciplinas->arquivosDisciplina();
        $conteudo['disciplinas'] = $this->Disciplinas->listarDisciplinas();
        $this->load->view('adm',$conteudo);	
       }else{
        $this->load->model('Disciplinas','',TRUE); 
        $this->load->model('Tecnicos','',TRUE); 
        $conteudos['disciplinas'] = $this->Disciplinas->listarDisciplinas();
        $conteudos['tecnicos'] = $this->Tecnicos->listarTecnicos();
        $conteudos['acesso'] = 'negado';
		  $this->load->view('home',$conteudos);
       }
    }
   public function login(){
        $this->load->model('Login','',TRUE);    
        $usuario = $this->input->post('txt_camposenha');  
        $this->Login->verificacao($usuario); 
   }

	public function logout(){
        $this->load->model('Login','',TRUE);     
        $this->Login->logout(); 
   }
 }
