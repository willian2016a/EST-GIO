<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
   function __construct() {
        parent::__construct(); 
      /*  $this->load->helper('form');
        $this->load->helper('url'); 
        $this->load->helper('html');
        $this->load->helper('string');  
        */
		  $this->load->library('session');
    }


	public function index(){
        $this->load->model('Disciplinas','',TRUE); 
        $this->load->model('Tecnicos','',TRUE); 
        $conteudos['disciplinas'] = $this->Disciplinas->listarDisciplinas();
        $conteudos['tecnicos'] = $this->Tecnicos->listarTecnicos();
		  $this->load->view('home',$conteudos);	
		

		
	}
	
}
