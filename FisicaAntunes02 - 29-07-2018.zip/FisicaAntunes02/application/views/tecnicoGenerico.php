<!DOCTYPE html>
<html lang="pt-br">
    <head>
	   <meta charset="UTF-8">
	   <title>Física Antunes</title>
        <link href="http://localhost/FisicaAntunes02/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <script src="http://localhost/FisicaAntunes02/assets/jquery-3.2.0.min.js"  type="text/javascript"></script>
        <script src="http://localhost/FisicaAntunes02/assets/bootstrap/js/bootstrap.min.js"  type="text/javascript"></script>
		<link href="http://localhost/FisicaAntunes02/assets/css/estilosTecnico.css" rel="stylesheet">
    </head>
    <body>
	<div id="content">
    	<div id="<?php echo $logo;?>" class="eletronfoto">
		</div>
        <div id="<?php echo $logo;?>" class="topo">
			<div id="logo">
				<img id="logoCefet" src="http://localhost/FisicaAntunes02/assets/images/logoCefet.jpg"> 
			</div>
			<div id="titulo">
				<p id="titulo1">Pedro Antunes Duarte, MSc</p>
                <p id="titulo2">MESTRE EM CIÊNCIAS - MATERIAIS PARA ENGENHARIA</p>
			</div>
		</div>
    	<input type="checkbox" id="check">
  			<label for="check">&#9776;</label>
    	<div id="meenu">
        	<nav id="menunav">
        		<div id="center">
        	    <ul id="menu" class="nav nav-tabs">
        	        <li>
        	            <form action="http://localhost/FisicaAntunes02/home"><button id="menuu" type="submit" class="btn btn-default navbar-btn"><b>Home</b></button></form>
        	         </li>                        
                    	<li>
                     		<a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" id="menuu">Graduação<span class="caret"></span></a>
                    		<ul id="menuuu" class="dropdown-menu">
                          		<?php 
									foreach($disciplinas as $disciplina){
                        				?>
                        				<li>
                          	 				<?php 
												echo anchor(base_url("disciplina/disciplina/".$disciplina->nome),'<span id="drop">' . $disciplina->nome . '</span>');
                          	 				?>
                        				</li>
                          				<?php
                          					}
                        				?>
                     		</ul> 
                    	</li>
                    	<li>
                     		<a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" id="menuu">Técnicos<span class="caret"></span></a>
                     		<ul id="menuuu" class="dropdown-menu">
                          		<?php 
									foreach($tecnicos as $tecnico){
                        	  ?>
                  			   <li>
                           	 <?php echo anchor(base_url("tecnico/tecnico/".$tecnico->nomeTecnico),'<span id="drop">' . $tecnico->nomeTecnico. '</span>');
                           	 ?> 
                          		</li>
                       
                         				<?php
                          					}
                        				?>
                     		</ul> 
                    	</li>
                     <li>
                        <form action="http://localhost/FisicaAntunes02/evento"><button id="menuu" type="submit" class="btn btn-default navbar-btn"><b>Eventos</b></button></form>
                     </li>
                    	<li>
    <?php if($this->session->userdata('logado') == 'TRUE'){
           $subADM = array('class' => 'btn btn-default dropdown-toggle','id' => 'menuu');
           echo form_open(base_url("adm")) .
                form_submit('nomequalquer','Administração',$subADM).
                form_close();
         }else{
          ?>
<button type="button" class="btn btn-default navbar-btn" id="menuu" data-toggle="modal" data-target="#loginADM">Administração</button>
           	<div class="modal fade" id="loginADM" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            	<div class="modal-dialog" role="document">
            	    <div class="modal-content">
            	        <div class="modal-header">
            	            <h4 class="modal-title" id="exampleModalLabel02">Para permissões administrativas, insira sua senha:</h4>
            	        </div>
            	        <div class="modal-body">
           		            <div class="form-group">
           		                <?php
                                $infoss = array('class' => 'form-label');
          		                $info = array('class' => 'form-control');
          		                $infos = array('class' => 'btn btn-default dropdown-toggle','id' => 'botao');
	      		                   echo form_open(base_url("adm/login")) .
          		                    form_label("Senha: " ,"txt_senha",$infoss).br() .
                                       form_input("txt_camposenha",'',$info) . br().
                                       form_submit('nomequalquer','Enviar Mensagem',$infos).
                                       form_close();
            	                ?>
            	            </div>
            	        </div>  
            	    </div>
            	</div>
        	</div>
     <?php
         }
     ?>





                          
                    	</li>
                    	<li>   
                        	<button type="button" class="btn btn-default navbar-btn" id="menuu" data-toggle="modal" data-target="#exampleModal"><b>Contato</b></button> 
                    	</li>   
            	</ul>  
                </div>
        	</nav>
			<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
	            <div class="modal-dialog" role="document">
	                <div class="modal-content">
	                    <div class="modal-body">
          
             Telefones (CEFET - Formação Geral): (35) 3690-4216  <br>
                                                (35) 3690-4214  <br>
                                                (35) 3690-4234  <br>
             Email: pedroantunes.pd@gmail.com <br>
                    antunes.pd@gmail.com
        
	                    </div>
	                </div>
	            </div>
	        </div>
	        </div>
            
            
  <div id="nomeTecnico">
    Técnico -  
    <?php 
        echo $nomeTecnico;
    ?>
        </div>     
 <div id="info">           
        	<div class="modal fade" id="exampleModal02" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            	<div class="modal-dialog" role="document">
            	    <div class="modal-content">
            	        <div class="modal-header">
            	            <h4 class="modal-title" id="exampleModalLabel02">Para permissões administrativas, insira sua senha:</h4>
            	        </div>
            	        <div class="modal-body">
           		            <div class="form-group">
           		                <?php
                                $infoss = array('class' => 'form-label');
          		                $info = array('class' => 'form-control');
          		                $infos = array('class' => 'btn btn-default dropdown-toggle','id' => 'botao');
	      		                   echo form_open(base_url("home/login")) .
          		                    form_label("Senha: " ,"txt_senha",$infoss).br() .
                                       form_input("txt_camposenha",'',$info) . br().
                                       form_submit('nomequalquer','Enviar Mensagem',$infos).
                                       form_close();
            	                ?>
            	            </div>
            	        </div>  
            	    </div>
            	</div>
        	</div>
<!--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-->
<!--
 <table >  
   <?php    
    foreach($arquivosTecnico as $arquivoTecnico){
    ?>
   <tr>
     <td>
   <?php 
     $ext = pathinfo($arquivoTecnico->nomeArquivo);
      $ext = $ext['extension'];
     if($ext == ('jpg') || $ext == ('png') || $ext == ('pdf') ){ 
  $submitDownload = array('name'=>'nomeArquivo','value'=>$arquivoTecnico->nomeArquivo,'class'=>'btn btn-default navbar-btn');
          echo form_open_multipart("tecnico/download").
          form_submit($submitDownload). 
          form_hidden('campo_nomeArquivo',$arquivoTecnico->nomeArquivo).
          form_hidden('campo_idTecnico',$arquivoTecnico->idTecnico).
          form_close();
    }

    ?>
     </td>
     </tr>
   <?php 
    }
    ?>   
</table>
   -->
 <table id="tabela1">
     <tr>
        <td id="subTitulo">
            <p>Segue a lista de arquivos enviados pelo professor Pedro Duarte referentes à turma
            <?php 
                echo $nomeTecnico;
            ?>:</p>
        </td>
         </tr>
     <tr>
         <td>
            <p id="bimestre1">1° Bimestre</p>
        </td>
    </tr>
  <?php    
     $co='0';
     if(!empty($arquivosTecnico)){
    foreach($arquivosTecnico as $arquivoTecnico){
    ?>
   <tr>
     <td>
   <?php 
     //$ext = pathinfo($arquivoTecnico->nomeArquivo);
     // $ext = $ext['extension'];
     if($arquivoTecnico->bimestre == '1' ){   
  $submitDownload = array('content'=>" ".$arquivoTecnico->nomeArquivo, 'name'=>'nomeArquivo','type'=>'submit','value'=>$arquivoTecnico->nomeArquivo,'class'=>'glyphicon glyphicon-cloud-download','id'=>'arqDownload');
          echo form_open_multipart("tecnico/download").
          form_button($submitDownload).
          form_hidden('campo_nomeArquivo',$arquivoTecnico->nomeArquivo).
          form_hidden('campo_idTecnico',$arquivoTecnico->idTecnico).
          form_close();
         $co='1';
    }     
    ?>
     </td>
     </tr>
   <?php 
    }
    if($co == '0'){ 
           ?>
        <div id="empty1">
    <?php
        echo 'Ainda não há arquivos';
    }
    ?>
        </div>
     <?php
 }else{
        ?>
        <div id="empty1">
    <?php
        echo 'Ainda não há arquivos';
    }
    ?>
        </div>
</table> 

 <table id="tabela2">
     <tr>
         <td>
            <p  id="bimestre">2° Bimestre</p>
        </td>
    </tr>
  <?php    
     $co='0';
     if(!empty($arquivosTecnico)){
    foreach($arquivosTecnico as $arquivoTecnico){
    ?>
   <tr>
     <td>
   <?php 
     //$ext = pathinfo($arquivoTecnico->nomeArquivo);

     // $ext = $ext['extension'];
     if($arquivoTecnico->bimestre == '2' ){   
  $submitDownload = array('content'=>" ".$arquivoTecnico->nomeArquivo, 'name'=>'nomeArquivo','type'=>'submit','value'=>$arquivoTecnico->nomeArquivo,'class'=>'glyphicon glyphicon-cloud-download','id'=>'arqDownload');
          echo form_open_multipart("tecnico/download").
          form_button($submitDownload).
          form_hidden('campo_nomeArquivo',$arquivoTecnico->nomeArquivo).
          form_hidden('campo_idTecnico',$arquivoTecnico->idTecnico).
          form_close();
         $co='1';
    }

    ?>
     </td>
     </tr>
   <?php 
    }
    if($co == '0'){ 
           ?>
        <div id="empty2">
    <?php
        echo 'Ainda não há arquivos';
    }
    ?>
        </div>
     <?php
 }else{
        ?>
        <div id="empty2">
    <?php
        echo 'Ainda não há arquivos';
    }
    ?>
     </div>
</table>

  <table id="tabela3">
      <tr>
         <td>
            <p  id="bimestre">3° Bimestre</p>
        </td>
    </tr>
  <?php
      $co = '0';
    if(!empty($arquivosTecnico)){
    foreach($arquivosTecnico as $arquivoTecnico){
    ?>
   <tr>
     <td>
   <?php 
     //$ext = pathinfo($arquivoTecnico->nomeArquivo);

     // $ext = $ext['extension'];
     if($arquivoTecnico->bimestre == '3' ){   
  $submitDownload = array('content'=>" ".$arquivoTecnico->nomeArquivo, 'name'=>'nomeArquivo','type'=>'submit','value'=>$arquivoTecnico->nomeArquivo,'class'=>'glyphicon glyphicon-cloud-download','id'=>'arqDownload');
          echo form_open_multipart("tecnico/download").
          form_button($submitDownload).
          form_hidden('campo_nomeArquivo',$arquivoTecnico->nomeArquivo).
          form_hidden('campo_idTecnico',$arquivoTecnico->idTecnico).
          form_close();
         $co = '1';
    }

    ?>
     </td>
     </tr>
   <?php 
    }
    if($co == '0'){ 
           ?>
        <div id="empty3">
    <?php
        echo 'Ainda não há arquivos';
    }
    ?>
        </div>
     <?php
 }else{
        ?>
        <div id="empty3">
    <?php
        echo 'Ainda não há arquivos';
    }
    ?>
     </div>
</table>

 <table id="tabela4">
     <tr >
         <td>
            <p id="bimestre">4° Bimestre</p>
        </td>
    </tr>
  <?php
     $co = '0';
     if(!empty($arquivosTecnico)){
    foreach($arquivosTecnico as $arquivoTecnico){
    ?>
   <tr>
     <td>
   <?php 
     //$ext = pathinfo($arquivoTecnico->nomeArquivo);

     // $ext = $ext['extension'];
     if($arquivoTecnico->bimestre == '4' ){   
  $submitDownload = array('content'=>" ".$arquivoTecnico->nomeArquivo, 'name'=>'nomeArquivo','type'=>'submit','value'=>$arquivoTecnico->nomeArquivo,'class'=>'glyphicon glyphicon-cloud-download','id'=>'arqDownload');
          echo form_open_multipart("tecnico/download").
          form_button($submitDownload).
          form_hidden('campo_nomeArquivo',$arquivoTecnico->nomeArquivo).
          form_hidden('campo_idTecnico',$arquivoTecnico->idTecnico).
          form_close();
         $co = '1';
    }

    ?>
     </td>
     </tr>
   <?php 
    }
    if($co == '0'){ 
           ?>
        <div id="empty4">
    <?php
        echo 'Ainda não há arquivos';
    }
    ?>
        </div>
     <?php
 }else{
        ?>
        <div id="empty4">
    <?php
        echo 'Ainda não há arquivos';
    }
    ?>
     </div>
     <tr>
        <td id="ultArqDownload">
            .
        </td>
    </tr>
</table> 
        </div>
			
			<img id="invisivel" src="http://localhost/FisicaAntunes02/assets/images/invisivel.png">
            <img id="Einsten"src="http://localhost/FisicaAntunes02/assets/images/Einsten.jpg">
            <div id="rodape">
                <p id="rodapeC">&copy; CEFET-MG Unidade VIII | all rights reserved</p>
                <p id="nRodape">Projeto Física Antunes</p>
                <p id="dRodape">Desenvolvedores:<br> Edgard Alexandre e Willian Alves</p>
                <p id="fRodape">"A imaginação é mais importante que o conhecimento."</p>
                <!--<span id="raio" class="glyphicon glyphicon-flash"></span>
                <span id="fogo" class="glyphicon glyphicon-fire"></span>
                <span id="folha" class="glyphicon glyphicon-leaf"></span>
                <span id="gota" class="glyphicon glyphicon-tint"></span>--> 
                <p id="contatoC">Dados da Instituição:</p>
                <p id="contatoCefet">Telefone: +55 (35) 3690-4200 <br> Endereço: Avenida dos Imimgrantes, 1000 <br> Bairro Vargem, Varginha - MG - Brasil <br> CEP: 37.022-560</p>
            </div>
            <div id="rodape2">rodape</div>
		</div>
    </body>
</html>




