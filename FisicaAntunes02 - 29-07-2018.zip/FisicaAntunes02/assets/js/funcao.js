function verificacao(batata) {
	var variavel = document.getElementById("banana").value;
	var bar = document.querySelector(".bombom").value;
	var mensagem = "testando!!"
	alert(batata);
}